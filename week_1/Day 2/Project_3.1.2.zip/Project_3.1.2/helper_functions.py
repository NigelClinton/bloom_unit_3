class DataExplore:

    def __init__(self, df):
        self.df = df

    def null_count_df(df):
        """Function to calculate null count, percentage of null values, and a 0/1 if null values are greater than .995."""
        frame = pd.DataFrame()
        frame['missing_no'] = df.isnull().sum()
        frame['missing_rate'] = df.isnull().sum() / len(df)
        frame = frame.loc[frame['missing_rate'] > 0].sort_values(
            by='missing_rate', ascending=False)
        frame['bigger_005'] = frame['missing_rate'].map(
            lambda x: 1 if x >= 0.05 else 0)
        return frame

    def zero_count(df):
        """Function to create a dataframe that looks at all columns values that are equal to 0"""
        df.eq(0).sum().to_frame(name='zero_count')
